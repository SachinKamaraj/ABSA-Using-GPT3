#!/usr/bin/env python
# coding: utf-8

# #### Setup
# 
# Be sure to setup the `OPENAI_API_KEY` environment variable before running this notebook.

# In[1]:


import os 
import logging
import sys

# Setup OPENAI_API_KEY

os.environ["OPENAI_API_KEY"] = "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"

# Setup logging

log = logging.getLogger(__name__)
logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s", level=logging.INFO)

# Update sys.path (or use PYTHONPATH)

sys.path.insert(0, '..')


# #### Read feedbacks
# 
# Let's read the feedback data scraped previously using the `scraping.ipynb` notebook.

# In[2]:


import pandas as pd

df = pd.read_csv("Datas/feedbacks.csv").dropna()

df.head()


# #### Filter & Sampling
# 
# For simplicity, we will keep only the feedbacks that have less than 300 chars and sample 15 items.

# In[3]:


# Filter feedbacks text below 300 characters
df = df[df.text.str.len() < 300].reset_index(drop=True)

# Sample n feedbacks
df = df.sample(n=15).reset_index()

df.head()


# #### Analysis
# 
# Here is a simple analysis loop that will send the feedbacks to GPT-3 and parse the JSON response. The analysis could take some time, depending on the number of feedbacks and on OpenAI account type.
# 
# At the end, it updates the main dataframe with a new JSON column for each feedback and save the dataframe as CSV.

# In[4]:


from random import choice
from tqdm.notebook import tqdm
from gpt3 import analyze
from json import loads
from pprint import pprint
from textwrap import dedent

analysis_results = []
extra_prompts = []

logging.getLogger("openai").setLevel(logging.INFO)
logging.getLogger("requests").setLevel(logging.WARNING)

for i in tqdm(range(len(df)), desc="Analyzing reviews"):
    title = df.loc[i, "title"]
    text = df.loc[i, "text"]

    log.info(f"Analyzing feedback - \nTitle: {title}\nText: {text}\n")

    extra_prompt = choice(extra_prompts) if extra_prompts else ""

    res = analyze(
        text=text,
        extra_prompt="",
        max_tokens=1024,
        temperature=0.1,
        top_p=1,
    )

    raw_json = res["choices"][0]["text"].strip()

    try:
        json_data = loads(raw_json)
        analysis_results.append(json_data)

        log.debug(f"JSON response: {pprint(json_data)}")

        extra_prompts.append(f"\n{text}\n{raw_json}")
    except Exception as e:
        log.error(f"Failed to parse '{raw_json}' -> {e}")
        analysis_results.append([])

df["analysis"] = analysis_results
df.to_csv("Datas/feedbacks_analysis.csv", index=False)


# #### Playing with analysis results
# 
# Start from here if you want to play or display the analysis results.

# In[5]:


# import pandas as pd

# df = pd.read_csv("./feedbacks_analysis.csv")

# df


# # In[6]:


# from ast import literal_eval

# df.analysis = df.analysis.apply(literal_eval)

# analysis_results = df.analysis

# analysis_results[:5]


# # In[7]:


# import numpy as np

# annotations = []

# for i, entry in enumerate(analysis_results):
#     for a in entry:
#         a["review_id"] = i
#         annotations.append(a)

# analysis_df = pd.DataFrame(annotations)

# analysis_df.to_csv("./analysis.csv", index=False)

# analysis_df

# analysis_df["sentiment_bin"] = np.where(analysis_df["sentiment"] == "positive", 0, 1)
# analysis_df


# # In[11]:


# import plotly.express as px

# fig = px.bar(
#     analysis_df,
#     x="aspect",
#     color="sentiment",
#     barmode="stack",
#     color_discrete_map={
#         "positive": "#52AC5E",
#         "negative": "#e34a2d",
#         "neutral": "gray",
#     },
#     title="Aspect vs Sentiment",
#     template="plotly_white",
# )

# fig.show(renderer='colab')


# In[10]:


# import plotly.express as px
# import plotly.io as pio

# fig = px.pie(
#         data_frame=analysis_df,
#         values=analysis_df.sentiment_bin.index,
#         names='sentiment',
#         title='Positive versus Negative',
#         color_discrete_sequence=px.colors.sequential.RdBu,
#         )

# pio.show(fig)


# In[13]:


# import plotly.express as px
# import pandas as pd
# from wordcloud import WordCloud 
# import numpy as np
# from matplotlib import pyplot as plt

# analysis_df['aspect_positive'] = np.where(analysis_df["sentiment"] == "positive",analysis_df['aspect'],"")
# data=analysis_df['aspect_positive'].value_counts().to_dict()
# wc=WordCloud().generate_from_frequencies(data)

# plt.imshow(wc)
# plt.axis('off')
# plt.show()


# # In[14]:


# import plotly.express as px
# import pandas as pd
# from wordcloud import WordCloud 
# import numpy as np
# from matplotlib import pyplot as plt

# analysis_df['aspect_negative'] = np.where(analysis_df["sentiment"] == "positive","",analysis_df['aspect'])
# data=analysis_df['aspect_negative'].value_counts().to_dict()
# wc=WordCloud().generate_from_frequencies(data)

# plt.imshow(wc)
# plt.axis('off')
# plt.show()


# #### Display results in console
# 
# This will display the annotated feedbacks in the console.


from rich.console import Console

console = Console()

for i, review in enumerate(df.to_dict("records")):
    text = review["text"]

    try:

        for ann in analysis_results[i]:
            color = "green" if ann["sentiment"] == "positive" else "red"
            text = text.replace(
                ann["segment"],
                f" [bold white on {color}]{ann['segment']}[/bold white on {color}] ([orange1]{ann['aspect']}[/orange1])",
            )

        console.print(f"{review['title']}\n\n{text}")

    except Exception as e:
        print(f"Failed to parse {review['title']} {e}")
        continue


# #### Display results in HTML
# 
# This will display the annotated feedbacks in a prettier way using HTML.

# In[ ]:


import re
from IPython.display import display, HTML
from html import escape

css = """
<style>
    .container {
        background-color: #fff;
        padding: 15px
    }

    p.feedback {
        margin-top: 5px;
        color: #595f6d;
        line-height: 2
    }

    h5.title {
        color: #b6bcc8;
        margin: 15px 0 0 0;
        padding: 0;
        font-style: italic;
    }

    .annotation {
        color: #777;
        padding: 2px;
        font-weight: bold !important;
        border-radius: 1px;
        border-bottom: 4px solid;
    }

    .aspect {
        color: #6eb2e7;
        padding-left: 10px;
        font-size: 12px;
    }
</style>
"""


def ireplace(text, old, new):
    pattern = re.compile(old, re.IGNORECASE)
    return pattern.sub(new, text)


html = f"{css}"

for i, review in enumerate(df.to_dict("records")):
    text = escape(review["text"])

    try:
        for ann in analysis_results[i]:
            color = "#2bbf6d" if ann["sentiment"] == "positive" else "#cf2a43"

            text = ireplace(
                text,
                ann["segment"],
                f"<span class='annotation' style='border-color: {color}'>{escape(ann['segment'])} <span class='aspect'>{ann['aspect']}</span></span>",
            )

        html += f"""

            <div class='container'>
                <h5 class='title'>{review['title']}</h5>
                <p class='feedback'>{text}</p>
            </div>
        """

    except Exception as e:
        print(f"Failed to parse {review['title']} {e}")
        continue

display(HTML(html))
with open("C:/Users/Santhosh/Desktop/ABSA With GPT/HTML/reviews.html", "w") as file:
    # Write the html to the file
    file.write(html)
