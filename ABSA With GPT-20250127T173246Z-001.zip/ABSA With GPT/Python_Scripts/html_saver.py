import pickle
import base64
import sys

print(2)
df = sys.argv[1]

# Decode the base64 string into a bytes object
df = base64.b64decode(df)

# Deserialize the dataframe
df = pickle.loads(df)

analysis_results = []
analysis_results = df.analysis

from rich.console import Console

console = Console()

for i, review in enumerate(df.to_dict("records")):
    text = review["text"]

    try:

        for ann in analysis_results[i]:
            color = "green" if ann["sentiment"] == "positive" else "red"
            text = text.replace(
                ann["segment"],
                f" [bold white on {color}]{ann['segment']}[/bold white on {color}] ([orange1]{ann['aspect']}[/orange1])",
            )

        console.print(f"{review['title']}\n\n{text}")

    except Exception as e:
        print(f"Failed to parse {review['title']} {e}")
        continue


# #### Display results in HTML
# 
# This will display the annotated feedbacks in a prettier way using HTML.

# In[ ]:


import re
from IPython.display import display, HTML
from html import escape

css = """
<style>
    .container {
        background-color: #fff;
        padding: 15px
    }

    p.feedback {
        margin-top: 5px;
        color: #595f6d;
        line-height: 2
    }

    h5.title {
        color: #b6bcc8;
        margin: 15px 0 0 0;
        padding: 0;
        font-style: italic;
    }

    .annotation {
        color: #777;
        padding: 2px;
        font-weight: bold !important;
        border-radius: 1px;
        border-bottom: 4px solid;
    }

    .aspect {
        color: #6eb2e7;
        padding-left: 10px;
        font-size: 12px;
    }
</style>
"""


def ireplace(text, old, new):
    pattern = re.compile(old, re.IGNORECASE)
    return pattern.sub(new, text)


html = f"{css}"

for i, review in enumerate(df.to_dict("records")):
    text = escape(review["text"])

    try:
        for ann in analysis_results[i]:
            color = "#2bbf6d" if ann["sentiment"] == "positive" else "#cf2a43"

            text = ireplace(
                text,
                ann["segment"],
                f"<span class='annotation' style='border-color: {color}'>{escape(ann['segment'])} <span class='aspect'>{ann['aspect']}</span></span>",
            )

        html += f"""

            <div class='container'>
                <h5 class='title'>{review['title']}</h5>
                <p class='feedback'>{text}</p>
            </div>
        """

    except Exception as e:
        print(f"Failed to parse {review['title']} {e}")
        continue

display(HTML(html))

