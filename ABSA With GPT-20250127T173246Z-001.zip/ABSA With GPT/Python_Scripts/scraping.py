import subprocess
import streamlit as st
import sys

url = sys.argv[1]

start_url = url
spider_path = "Python_Scripts/amazon.py"
output_path = "Datas/feedbacks.csv:csv"

subprocess.run(["scrapy", "runspider", spider_path, "-o", output_path, "-a", f"start_url={start_url}"], shell=True)
