import sys
import pickle
import base64

analysis_df = sys.argv[1]

# Decode the base64 string into a bytes object
analysis_df = base64.b64decode(analysis_df)

# Deserialize the dataframe
analysis_df = pickle.loads(analysis_df)

analysis_df.to_csv("Datas/analysis.csv", index=False)
