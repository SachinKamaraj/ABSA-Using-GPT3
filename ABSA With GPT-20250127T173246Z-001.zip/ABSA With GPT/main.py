import streamlit as st
from streamlit_option_menu import option_menu
from apps import ABSA_on_Amazon_reviews, Documentation, home,ABSA_STT  # import your app modules here

st.set_page_config(page_title="Sentimentify", layout="wide")

# A dictionary of apps in the format of {"App title": "App icon"}
# More icons can be found here: https://icons.getbootstrap.com

apps = [
    {"func": home.app, "title": "Home", "icon": "house"},
    {"func": ABSA_on_Amazon_reviews.app, "title": "ABSA based on Reviews", "icon": "file-earmark-bar-graph"},
    {"func": ABSA_STT.app, "title": "ABSA based on Audio", "icon": "mic"},
    {"func": Documentation.app, "title": "Documentation", "icon": "file-earmark-medical"},
]

titles = [app["title"] for app in apps]
titles_lower = [title.lower() for title in titles]
icons = [app["icon"] for app in apps]

params = st.experimental_get_query_params()

if "page" in params:
    default_index = int(titles_lower.index(params["page"][0].lower()))
else:
    default_index = 0

with st.sidebar:
    selected = option_menu(
        "Sentimentify",
        options=titles,
        icons=icons,
        menu_icon="heart-half",
        
        default_index=default_index,
        
        
    )
    

with st.sidebar:
    st.warning('''
            This is a beta version
             ''')
    st.sidebar.title("About Sentimentify")
    st.sidebar.markdown(
    """
    Sentimentify is a web application that allows users to perform ABSA on Amazon product reviews using GPT-3 and displays results in dataframe, bar graph and wordcloud
    """
    )
    st.sidebar.title("About GPT-3")
    st.sidebar.markdown(
    """
    GPT-3 is a cutting-edge machine learning model that uses deep learning to generate human-like text. It is capable of understanding context and generating coherent and fluent responses.
    """
    )
    st.sidebar.title("About ABSA")
    st.sidebar.markdown(
    """
    Aspect-based Sentiment Analysis (ABSA) is a technique for understanding the attitudes, opinions and emotions of customers towards different aspects of a product or service. ABSA helps businesses to identify areas of improvement and gain insights into customer satisfaction.
    """
    )    

for app in apps:
    if app["title"] == selected:
        app["func"]()
        break